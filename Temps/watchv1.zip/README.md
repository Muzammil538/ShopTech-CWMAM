# SmartWatch
This is a Smart Watch project with Python , this is a CLI of the watch and will be show cased on the Shop-Tech web page.

## Features 
1. Time And Date :
    This shows the time and date (current)
2. Wifi : 
    This shows the available wifi networks.
3. Search (audio) : 
    This uses the mic and searches the query.
#### other features comming soon... 

 
